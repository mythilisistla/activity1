package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Employee;
import com.cg.service.EmployeeService;

@RestController
public class EmployeeRestController {

	@Autowired
	EmployeeService employeeService;
	@Autowired
	Employee employee;
	//url:http://localhost:8083/add/mythi/hyderabad/80000/consultant
	//method:post
	@PostMapping("/add/{name}/{address}/{salary}/{designation}")
	public Employee addEmployee(@PathVariable String name,@PathVariable String address,@PathVariable Double salary,@PathVariable String designation)
	{
		employee.setName(name);
		employee.setAddress(address);
		employee.setDesignation(designation);
		employee.setSalary(salary);
		Employee savedEmp=employeeService.addEmployee(employee);
		return savedEmp;
	}
	// This is to send as object
	@PostMapping(value = "/addobject",consumes={MediaType.APPLICATION_JSON_VALUE})
	public Employee addEmpObject(@RequestBody Employee employee ) {
		Employee savedEmp=employeeService.addEmployee(employee);
		return savedEmp;
	}
	
	//url:http//localhost:8083/viewall
	//method:get
	@GetMapping("/viewall")
	public List<Employee>viewAll()
	{
		return employeeService.getEmployees();
	}
	
	//Get
	//http://localhost:8083/viewaddress?address=banglore
	@GetMapping("/viewaddress")
	public List<Employee> viewAddress(@RequestParam String address){
		return employeeService.getEmployeesByAddress(address);
	}
	//Get
	//http://localhost:8083/viewaddress/banglore
	@GetMapping("/viewaddress/{address}")
	public List<Employee>viewAddressPath(@PathVariable String address){
		return employeeService.getEmployeesByAddress(address);
	}
	//GET
	//http://localhost:8083/viewdesignation?designation=trainee
	@GetMapping("/viewdesignation")
	public List<Employee> viewDesignation(@RequestParam String designation){
		return employeeService.getEmployeesByDesignation(designation);
	}
	//GET
	//http://localhost:8083/viewdesignation/trainee
	@GetMapping("/viewdesignation/{designation}")
	public List<Employee>viewDesignationPath(@PathVariable String designation){
		return employeeService.getEmployeesByDesignation(designation);
	}
	//delete
	//http://localhost:8083/deletebyid/3001
	@DeleteMapping("/deleteByid/{empId}")
	public String deleteById(@PathVariable Integer empId) {
		employeeService.deleteById(empId);
		return empId+" deleted";
	}
	//delete
	//http://localhost:8083/deleteall
	@DeleteMapping("/deleteall")
	public void deleteAll() {
		employeeService.deleteAll();
	}
	//get
		//http://localhost:8083/findbyid/3001
		@GetMapping("/findbyid/{empId}")
		public Employee findById(@PathVariable Integer empId) {
			return employeeService.findById(empId);
		}
		//get
		//http://localhost:8083/salaryrange/10000/60000
		@GetMapping("/salaryrange/{salary1}/{salary2}")
		public List<Employee> salaryRange(@PathVariable Double salary1,@PathVariable Double salary2){
			return  employeeService.salaryRange(salary1,salary2);
	}
		//get
				//http://localhost:8083/salaryrange?salary1=10000&salary2=60000
				@GetMapping("/salaryrange")
				public List<Employee> salaryRangeParam(@RequestParam Double salary1,@RequestParam Double salary2){
					return  employeeService.salaryRange(salary1,salary2);
				}
				//Post
				//http://localhost:8083/updateobject
		@PutMapping(value = "/updateobject",consumes={MediaType.APPLICATION_JSON_VALUE})
		public Employee updateEmpObject(@RequestBody Employee employee ) {
			Employee updateEmp=employeeService.updateEmployee(employee);
			return updateEmp;
		}
		
			//@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Invalid request")
			//@ExceptionHandler({Exception.class})
			//public void handleException() {
			}
			 



